java -jar tommy_pokerbot.jar "$@"

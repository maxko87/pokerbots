java -jar pokerbot.jar "$@"

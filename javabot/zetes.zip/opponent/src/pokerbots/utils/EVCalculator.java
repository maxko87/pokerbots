package pokerbots.utils;

public class EVCalculator {

	//PREFLOP
	//
	//EV folding is 0
	//
	//EV calling is (equity)*(size of pot after call)*TIO - (amount to call) - (chance we will have to fold this round*amount to call)
	//ev_call =   
	//
	//EV raising is (Equity when called)*(size of pot when called)*TIO + (% chance all fold)* (size of the pot with our raise) - (amount costs us to raise) - (EV loss when we have to fold after we raise)
	//
	
}
